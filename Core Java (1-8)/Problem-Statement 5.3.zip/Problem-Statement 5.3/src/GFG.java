
class GFG { 
	public static void main(String[] args) {
		String str= "MPHASIS", nstr="";
		char ch;
		System.out.println(str);
		StringBuilder sb=new StringBuilder(str);
		for (int i=0;i<str.length();i++)
		{
			ch = sb.charAt(0);
			sb.deleteCharAt(0);
			sb=sb.append(ch);
			System.out.println(sb);
		}
	}
}