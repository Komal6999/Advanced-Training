
public class Book
{
    private String book_title;
    private int bookPrice;
    
    
     public void setBook_title(String bookName)
    {
        this.book_title=bookName;
    }
    
    public String getBook_title()
    {
        return this.book_title;
    }
    
    public void setBookPrice(int bookPrice)
    {
        this.bookPrice=bookPrice;
    }
    
    public int getBookPrice()
    {
        return this.bookPrice;
    }
    
    
}